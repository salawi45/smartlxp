<?php

$string['configtitle'] = 'Block title';
$string['cocoon_tstmnls_4:addinstance'] = 'Add a new [Cocoon] Testimonials slider 4 block';
$string['cocoon_tstmnls_4:myaddinstance'] = 'Add a new [Cocoon] Testimonials slider 4 block to Dashboard';
$string['pluginname'] = '[Cocoon] Testimonials slider 4';
