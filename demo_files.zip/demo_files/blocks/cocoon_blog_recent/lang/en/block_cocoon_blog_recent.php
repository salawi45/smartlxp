<?php

$string['cocoon_blog_recent:addinstance'] = 'Add a new recent blog entries block';
$string['norecentblogentries'] = 'No recent entries';
$string['pluginname'] = '[Cocoon] Recent blog posts';
$string['privacy:metadata'] = 'The Recent blog entries block only shows data stored in other locations.';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
